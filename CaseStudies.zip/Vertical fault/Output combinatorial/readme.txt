Please note that the .vtu files for ParaView contain a subset of the F_vertical_output.txt file that
was illustrated in the article.