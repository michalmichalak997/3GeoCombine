1. Please note that the precision here is smaller than that of the fault dipping at 60 degrees.
This is because the fault cannot be a separator between geological units, 
so we do not need any extra specifically designed points which require a greater precision.

2. The case study associated with "F" is located in the "Input combinatorial" and "Output combinatorial" respectively.